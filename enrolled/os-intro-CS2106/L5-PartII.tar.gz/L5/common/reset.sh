cp *.img ../ex2/
cp *.img ../ex3/
